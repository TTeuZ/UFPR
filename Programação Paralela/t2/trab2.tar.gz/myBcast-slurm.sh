#!/bin/bash
mpirun -N 1 ./myBroadcast_rb 8000 4096 1 -r 0