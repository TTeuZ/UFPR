#!/bin/bash

mpirun -N 1 ./mmull 1800 1000 800